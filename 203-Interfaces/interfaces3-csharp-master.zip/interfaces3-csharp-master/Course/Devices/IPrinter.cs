﻿namespace Course.Devices {
    interface IPrinter {
        void Print(string document);
    }
}
