﻿namespace Course.Model.Entities {
    interface IShape {

        double Area();
    }
}
