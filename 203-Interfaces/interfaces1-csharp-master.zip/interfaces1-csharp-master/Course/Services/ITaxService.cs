﻿namespace Course.Services {
    interface ITaxService {

        double Tax(double amount);
    }
}